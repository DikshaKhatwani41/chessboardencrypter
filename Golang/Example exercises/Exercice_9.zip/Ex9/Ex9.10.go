package main

import (
	"fmt"
)

func main(){
	for i:=0;i<=10;i++{
		fmt.Println("Squre of ",i," is ",(i*i))
		fmt.Println("Cube of ",i," is ",(i*i*i))
	}
}
